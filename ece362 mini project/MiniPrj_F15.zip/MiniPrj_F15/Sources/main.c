/*
************************************************************************
 ECE 362 - Mini-Project C Source File - Fall 2015
***********************************************************************
      
 Team ID: <27 >

 Project Name: <Magic Matrix>

 Team Members:

   - Team/Doc Leader: < Junyan Shi >      Signature: ____Junyan Shi__________________
   
   - Software Leader: <Xiaoyuan Zhang >      Signature: ___Xiaoyuan Zhang___________________

   - Interface Leader: < Mengshi Feng>     Signature: ____Mengshi Feng__________________

   - Peripheral Leader: < Zhuofan Li >    Signature: ___Zhuofan Li___________________


 Academic Honesty Statement:  In signing above, we hereby certify that we 
 are the individuals who created this HC(S)12 source file and that we have
 not copied the work of any other student (past or present) while completing 
 it. We understand that if we fail to honor this agreement, we will receive 
 a grade of ZERO and be subject to possible disciplinary action.

***********************************************************************

 The objective of this Mini-Project is to .... < ? >
 use IR sensor to detect the user's motion and light on the corresponding LEDs.


***********************************************************************

 List of project-specific success criteria (functionality that will be
 demonstrated):

 1. User's motion will be detected.

 2. Different display modes

 3. LCD displays mode number and mode names

 4.

 5.

***********************************************************************

  Date code started: < 11/20 >

  Update history (add an entry every time a significant change is made):

  Date: < ? >  Name: < ? >   Update: < ? >

  Date: < ? >  Name: < ? >   Update: < ? >

  Date: < ? >  Name: < ? >   Update: < ? >


***********************************************************************
*/

#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include <mc9s12c32.h>

/* All functions after main should be initialized here */
char inchar(void);
void outchar(char x);
void ATD_SCAN(void);
void LEDOutput(void);
void ClearLedResult(void);
void mode3Recursive(void);
void shiftout(char x);
void lcdwait(void);
void send_byte(char x);
void send_i(char x);
void chgline(char x);
void print_c(char x);
void pmsglcd(char[]);



/* Variable declarations */
int mode = 0; //There are three modes in total
char LEDResult[8] = {0,0,0,0,0,0,0,0};
char LEDBlinkState[8] = {0,0,0,0,0,0,0,0};
int prvpb = 0;
unsigned long int i;//i index
int tenths;
int tencnt = 0;
int tenthcmp;
int test; 
int mode2Toggle;
int threshold = 70;  
unsigned long int k; 

int r = 0;
int pbflag = 0;         

/* Special ASCII characters */
#define CR 0x0D // ASCII return 
#define LF 0x0A // ASCII new line 

/* LCD COMMUNICATION BIT MASKS (note - different than previous labs) */
#define RS 0x10 // RS pin mask (PTT[4])
#define RW 0x20 // R/W pin mask (PTT[5])
#define LCDCLK 0x40 // LCD EN/CLK pin mask (PTT[6])

/* LCD INSTRUCTION CHARACTERS */
#define LCDON 0x0F // LCD initialization command
#define LCDCLR 0x01 // LCD clear display command
#define TWOLINE 0x38 // LCD 2-line enable command
#define CURMOV 0xFE // LCD cursor move instruction
#define LINE1  0x80 // LCD line 1 cursor position
#define LINE2  0xC0 // LCD line 2 cursor position

 
/*  
***********************************************************************
 Initializations
***********************************************************************
*/

void  initializations(void) {

/* Set the PLL speed (bus clock = 24 MHz) */
  CLKSEL = CLKSEL & 0x80; //; disengage PLL from system
  PLLCTL = PLLCTL | 0x40; //; turn on PLL
  SYNR = 0x02;            //; set PLL multiplier
  REFDV = 0;              //; set PLL divider
  while (!(CRGFLG & 0x08)){  }
  CLKSEL = CLKSEL | 0x80; //; engage PLL

/* Disable watchdog timer (COPCTL register) */
  COPCTL = 0x40   ; //COP off; RTI and COP stopped in BDM-mode

/* Initialize asynchronous serial port (SCI) for 9600 baud, interrupts off initially */
  SCIBDH =  0x00; //set baud rate to 9600
  SCIBDL =  0x9C; //24,000,000 / 16 / 156 = 9600 (approx)  
  SCICR1 =  0x00; //$9C = 156
  SCICR2 =  0x0C; //initialize SCI for program-driven operation
  DDRB   =  0x10; //set PB4 for output mode
  PORTB  =  0x10; //assert DTR pin on COM port

/* Initialize peripherals */

/*Initialize ATD*/

  DDRAD = 0x00;//Initalize directional register so that all the ATD pins are input
  ATDCTL2 = 0x80; //ATDCTL2 = 1000,0000, able the ATD, normal CCF flag clearing and ATD interrupt disabled
  ATDCTL3 = 0x00; //ATDCTL3 = 0000,0000, conversion length is 8 and result register mode is non-FIFO
  ATDCTL4 = 0x85;   //ATDCTL4 = 1000, 0101   
  ATDCTL5 = 0x10;   //ATDCTL5 = 0001, 0111, left justified, unsigned data, single conversion sequence performed, multiple chanels and start from chanel 7
  ATDDIEN = 0x00; //Analog input select
   
/*End of initialize ATD*/

/*Initalize T port*/

  

/*End of Initialize ATD*/
         
/* Initialize interrupts */

 RTICTL = 0x7F;
 CRGINT = 0x80;
 DDRM = 0x30;
 SPIBR =0x01;
 SPICR1 =0x50;
 DDRT = 0xFF; //Initialize directional register so that all the T pins are output
    
/*End of initialize interrupts*/

/*  Initialize M port*/

  DDRM = 0x30;
  
/*  End of initialize M port*/ 

/*  Initialize TIM */
  
  TIOS = 0x80;  //TIOS = 1000, 0000
  TSCR1 = 0x80; //TSCR1 = 1000, 0000
  TSCR2 = 0x0C;
  TIE = 0x80;
  TC7 = 15000;
    
/*  End of initialize TIM */ 
       
/* Initialize the LCD
     - pull LCDCLK high (idle)
     - pull R/W' low (write state)
     - turn on LCD (LCDON instruction)
     - enable two-line mode (TWOLINE instruction)
     - clear LCD (LCDCLR instruction)
     - wait for 2ms so that the LCD can wake up     
*/ 
    PTT_PTT2 =1;
    PTT_PTT1 =0;
    send_i(LCDON);
    send_i(TWOLINE);
    send_i(LCDCLR);
    lcdwait();     
}



void ClearLedResult(void) {
    for(i = 0;i < 8; i++) {
     LEDResult[i] = 0; 
    }
  
}

void ATD_SCAN(void) {
  
    ATDCTL5 = 0x10; //ATDCTL5 = 0x0001, 0000
    
   
    
    while(ATDSTAT0_SCF == 0) {
    
    }
    
    
}

void LEDOutput(void) {
     
     
     PTT_PTT0 = LEDResult[0]; 
     PTT_PTT1 = LEDResult[1];
     PTT_PTT2 = LEDResult[2];
     PTT_PTT3 = LEDResult[3];
     PTT_PTT4 = LEDResult[4];
     PTT_PTT5 = LEDResult[5];
     PTT_PTT6 = LEDResult[6];
     PTT_PTT7 = LEDResult[7]; 
     
    
     
     //PTT = 0x01;
     
  
}

void mode3Recursive(void) {
 // int k;
 
  

  if(mode != 3) {
    return;
  }
  
  if(!(LEDBlinkState[0] | LEDBlinkState[1] | LEDBlinkState[2] | LEDBlinkState[3] | LEDBlinkState[4] | LEDBlinkState[5] | LEDBlinkState[6] | LEDBlinkState[7])) {
    
    for(k = 0; k < 8; k++) {
      LEDResult[k] = 0;
      LEDOutput();  
      
    }
    return;
  }
  
  r++;
  for(k = 0;k < 8; k++) {
    LEDResult[k] = LEDBlinkState[k] % 2;
    if(LEDBlinkState[k] != 0) {
        LEDBlinkState[k]--;
    }
  }
    
    LEDOutput();
    
    for(k = 0; k < 80000; k++) {
      
      
    }
    
    mode3Recursive();
    
    
    
  
  
  
  
  
  
}

    
/*     
***********************************************************************
Main
***********************************************************************
*/
void main(void) {
  DisableInterrupts
initializations();     
EnableInterrupts;

 for(;;) {
   send_i(LCDON);

  
  
  if(tenths == 1) {
    tenths = 0;
    
  
/* < start of your main loop > */ 
  if(mode == 0) {//All off
   //send_i(LCDCLR);
   chgline(LINE1);
   pmsglcd("Mode = ");
   print_c(mode + 48);
   chgline(LINE2);
   
   pmsglcd("Turned off!     ");   
     ClearLedResult();
     LEDOutput();
     
     
     
    
   
  } else if(mode == 1) {//
   send_i(LCDCLR);
     chgline(LINE1);
     pmsglcd("Mode = "); 
     print_c(mode + 48);
     chgline(LINE2);
   
     pmsglcd("Magic shift");
    tenthcmp = 10;
    TC7 = 15000;
    
    ATD_SCAN();
    LEDResult[0] = (ATDDR0H <= threshold);
    LEDResult[1] = (ATDDR1H <= threshold);
    LEDResult[2] = (ATDDR2H <= threshold);
    LEDResult[3] = (ATDDR3H <= threshold);
    LEDResult[4] = (ATDDR4H <= threshold);
    LEDResult[5] = (ATDDR5H <= threshold);
    LEDResult[6] = (ATDDR6H <= threshold);
    LEDResult[7] = (ATDDR7H <= threshold);
    
    
     
   

    
    
    LEDOutput();
  } else if(mode == 2) {
  
      send_i(LCDCLR);
     chgline(LINE1);
     pmsglcd("Mode = 2 ");
    
     chgline(LINE2);
   
     pmsglcd("Eternal");
     
    tenthcmp = 10;
    TC7 = 8000;
    if((LEDResult[0] & LEDResult[1]  & LEDResult[2]  & LEDResult[3]  & LEDResult[4]  & LEDResult[5] & LEDResult[6] & LEDResult[7]) | (!LEDResult[0] & !LEDResult[1]  & !LEDResult[2]  & !LEDResult[3]  & !LEDResult[4]  & !LEDResult[5] & !LEDResult[6] & !LEDResult[7])) {
         mode2Toggle = 1 - LEDResult[0];
    
         for(i = 0; i < 250000; i++) {
          
         }
    }
    
    ATD_SCAN();
    LEDResult[0] =  ((ATDDR0H <= threshold) & (1 - LEDResult[0]) & (mode2Toggle != LEDResult[0])) | (LEDResult[0] & ((ATDDR0H > threshold) | (mode2Toggle == LEDResult[0])));
    LEDResult[1] =  ((ATDDR1H <= threshold) & (1 - LEDResult[1]) & (mode2Toggle != LEDResult[1])) | (LEDResult[1] & ((ATDDR1H > threshold) | (mode2Toggle == LEDResult[1])));
    LEDResult[2] =  ((ATDDR2H <= threshold) & (1 - LEDResult[2]) & (mode2Toggle != LEDResult[2])) | (LEDResult[2] & ((ATDDR2H > threshold) | (mode2Toggle == LEDResult[2])));
    LEDResult[3] =  ((ATDDR3H <= threshold) & (1 - LEDResult[3]) & (mode2Toggle != LEDResult[3])) | (LEDResult[3] & ((ATDDR3H > threshold) | (mode2Toggle == LEDResult[3])));
    LEDResult[4] =  ((ATDDR4H <= threshold) & (1 - LEDResult[4]) & (mode2Toggle != LEDResult[4])) | (LEDResult[4] & ((ATDDR4H > threshold) | (mode2Toggle == LEDResult[4])));
    LEDResult[5] =  ((ATDDR5H <= threshold) & (1 - LEDResult[5]) & (mode2Toggle != LEDResult[5])) | (LEDResult[5] & ((ATDDR5H > threshold) | (mode2Toggle == LEDResult[5])));
    LEDResult[6] =  ((ATDDR6H <= threshold) & (1 - LEDResult[6]) & (mode2Toggle != LEDResult[6])) | (LEDResult[6] & ((ATDDR6H > threshold) | (mode2Toggle == LEDResult[6])));
    LEDResult[7] =  ((ATDDR7H <= threshold) & (1 - LEDResult[7]) & (mode2Toggle != LEDResult[7])) | (LEDResult[7] & ((ATDDR7H > threshold) | (mode2Toggle == LEDResult[7])));
    
  
  
  
    LEDOutput();
    
  } else if (mode == 3) {//potential problem with the time
  send_i(LCDCLR);
     chgline(LINE1);
     pmsglcd("Mode = ");
     print_c(mode + 48);
     chgline(LINE2);
     pmsglcd("Sky full of star");
    
    TC7 = 15000;
    
    tenthcmp = 10;
    
    
    test = 3;
    
    
    mode3Recursive();
    
    test = 0;
    
    
     
   
    
    
    
    
    
  
    
  }
  
    
  }
   

  
   } /* loop forever */
   
  }   /* do not leave main */




/*
***********************************************************************                       
 RTI interrupt service routine: RTI_ISR
************************************************************************
*/

interrupt 7 void RTI_ISR(void)
{
  // clear RTI interrupt flagt 
  CRGFLG = CRGFLG | 0x80; 
    if(prvpb != PTM_PTM2) {
     
        if(mode == 3) {
          mode = 0;  
        } else {
          mode++;  
        }
      
    }

    prvpb = PTM_PTM2; 
   
       
    
  
  

    
}

/*
***********************************************************************                       
  TIM interrupt service routine   
***********************************************************************
*/

interrupt 15 void TIM_ISR(void)
{
  // clear TIM CH 7 interrupt flag 
  TFLG1 = TFLG1 | 0x80;
  
  if(tencnt >= tenthcmp) {
   tenths = 1;
   tencnt = 0;
  }
  
  tencnt++;
  
  
  
  if(mode == 3) {
   ATD_SCAN();
  
   LEDBlinkState[0] = (ATDDR0H <= threshold) * 5 + (ATDDR0H > threshold) * LEDBlinkState[0];
    LEDBlinkState[1] = (ATDDR1H <= threshold) * 5 + (ATDDR1H > threshold) * LEDBlinkState[1];
    LEDBlinkState[2] = (ATDDR2H <= threshold) * 5 + (ATDDR2H > threshold) * LEDBlinkState[2];
    LEDBlinkState[3] = (ATDDR3H <= threshold) * 5 + (ATDDR3H > threshold) * LEDBlinkState[3];
    LEDBlinkState[4] = (ATDDR4H <= threshold) * 5 + (ATDDR4H > threshold) * LEDBlinkState[4];
    LEDBlinkState[5] = (ATDDR5H <= threshold) * 5 + (ATDDR5H > threshold) * LEDBlinkState[5];
    LEDBlinkState[6] = (ATDDR6H <= threshold) * 5 + (ATDDR6H > threshold) * LEDBlinkState[6];
    LEDBlinkState[7] = (ATDDR7H <= threshold) * 5 + (ATDDR7H > threshold) * LEDBlinkState[7];
    
   
   
   
  }
 

}

/*
***********************************************************************                       
  SCI interrupt service routine   
***********************************************************************
*/

interrupt 20 void SCI_ISR(void)
{
 


}

/*
***********************************************************************
  shiftout: Transmits the character x to external shift 
            register using the SPI.  It should shift MSB first.  
             
            MISO = PM[4]
            SCK  = PM[5]
***********************************************************************
*/
 
void shiftout(char x)

{
  int i =30;
  // read the SPTEF bit, continue if bit is 1
  // write data to SPI data register
  // wait for 30 cycles for SPI data to shift out 
  while(SPISR_SPTEF ==0) {
  }
  SPIDR = x;
  
  while(i>0){
    i--;
  }
  
}

/*
***********************************************************************
  lcdwait: Delay for approx 2 ms
***********************************************************************
*/

void lcdwait()
{
   int a = 6;
   int b = 8000;
   while(a!=0) {
    while(b!=0){
      b--;
    }
    a--;
   }
}

/*
*********************************************************************** 
  send_byte: writes character x to the LCD
***********************************************************************
*/

void send_byte(char x)
{
     // shift out character
     // pulse LCD clock line low->high->low
     // wait 2 ms for LCD to process data
     shiftout(x);
     PTT_PTT2 =0;
     PTT_PTT2 =1;
     PTT_PTT2 =0;
     lcdwait();
     
}

/*
***********************************************************************
  send_i: Sends instruction byte x to LCD  
***********************************************************************
*/

void send_i(char x)
{
        // set the register select line low (instruction data)
        // send byte
        PTT_PTT0=0;
        send_byte(x); 
}

/*
***********************************************************************
  chgline: Move LCD cursor to position x
  NOTE: Cursor positions are encoded in the LINE1/LINE2 variables
***********************************************************************
*/

void chgline(char x)
{
   send_i(CURMOV);
   send_i(x);
}

/*
***********************************************************************
  print_c: Print (single) character x on LCD            
***********************************************************************
*/
 
void print_c(char x)
{
   PTT_PTT0=1;
   send_byte(x);
}

/*
***********************************************************************
  pmsglcd: print character string str[] on LCD
***********************************************************************
*/

void pmsglcd(char str[])
{
   int i =0;
   while(str[i]!='\0'){
    print_c(str[i]);
    i++;
   }
}

/*
***********************************************************************
 Character I/O Library Routines for 9S12C32 
***********************************************************************
 Name:         inchar
 Description:  inputs ASCII character from SCI serial port and returns it
 Example:      char ch1 = inchar();
***********************************************************************
*/

char inchar(void) {
  /* receives character from the terminal channel */
        while (!(SCISR1 & 0x20)); /* wait for input */
    return SCIDRL;
}

/*
***********************************************************************
 Name:         outchar    (use only for DEBUGGING purposes)
 Description:  outputs ASCII character x to SCI serial port
 Example:      outchar('x');
***********************************************************************
*/

void outchar(char x) {
  /* sends a character to the terminal channel */
    while (!(SCISR1 & 0x80));  /* wait for output buffer empty */
    SCIDRL = x;
}